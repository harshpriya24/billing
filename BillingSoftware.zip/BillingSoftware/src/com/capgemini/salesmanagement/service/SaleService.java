package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exception.ProductNotFoundException;

public class SaleService implements ISaleService{
//Making object of  dao Service class
	ISaleDAO saleDAO=new SaleDAO();
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) throws ProductNotFoundException {
			return	 saleDAO.insertSalesDetails(sale);
	}
//validating product Id
	@Override
	public boolean validateProductCode(int productId) throws ProductNotFoundException {
		if(productId==1001||productId==1002||productId==1003||productId==1004)
			return true;
			else
		return false;
	}
//validating Quantity
	@Override
	public boolean validateQuantity(int qty) throws ProductNotFoundException{
		if(qty>0&&qty<5)
			return true;
		else
		return false;
	}
//validating Product Category
	@Override
	public boolean validateProductCat(String prodCat) throws ProductNotFoundException {
		Sale sale=new Sale(prodCat);
		if((prodCat.equalsIgnoreCase("Electronics")&&(sale.getProductName().equalsIgnoreCase("TV")||sale.getProductName().equalsIgnoreCase("Smart Phone")||sale.getProductName().equalsIgnoreCase("video game"))
				||(prodCat.equalsIgnoreCase("Toys")&&( sale.getProductName().equalsIgnoreCase("Soft Toy")||sale.getProductName().equalsIgnoreCase("Telescope")||sale.getProductName().equalsIgnoreCase("Barbee Doll")))))
		return true;
		else
			return false;
	}
//validating Product Price
	@Override
	public boolean validateProductPrice(float price) throws ProductNotFoundException {
		if(price>200)
		return true;
		else
			return false;
	}

	
	
}
