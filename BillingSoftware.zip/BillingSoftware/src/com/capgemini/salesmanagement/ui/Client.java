package com.capgemini.salesmanagement.ui;

import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {
	public static void main(String args[]) {
		ISaleService services=new SaleService();
		Sale sale=new Sale();
		int i=0;
		int index;
   while(i<3) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the product Id");
		int proId=sc.nextInt();
		sale.setProdCode(proId);
		System.out.println("Enter the Quantity");
		int qty=sc.nextInt();
		sale.setQuantity(qty);
		System.out.println("Enter Product Category");
		String prodCat=sc.next();
		sale.setCategory(prodCat);
		System.out.println("Product Name");
		String prodName=sc.next();
		sale.setProductName(prodName);
		System.out.println("Enter Product Description");
		String description=sc.next();
		System.out.println("Enter Price");
		int price=sc.nextInt();
		float lineTotal=price*qty;
		sale.setLineTotal(lineTotal);
		index=sc.nextInt();
		switch(index) {
		case 1: 
		}
		

   }

	}
}
